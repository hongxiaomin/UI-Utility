/* */ 
var $ = require('./$'),
    toIObject = require('./$.to-iobject'),
    isEnum = $.isEnum;
module.exports = function(isEntries) {
  return function(it) {
    var O = toIObject(it),
        keys = $.getKeys(O),
        length = keys.length,
        i = 0,
        result = [],
        key;
    while (length > i)
      if (isEnum.call(O, key = keys[i++])) {
        result.push(isEntries ? [key, O[key]] : O[key]);
      }
    return result;
  };
};
