/* */ 
require('./$.typed-array')('Float32', 4, function(init) {
  return function Float32Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});
