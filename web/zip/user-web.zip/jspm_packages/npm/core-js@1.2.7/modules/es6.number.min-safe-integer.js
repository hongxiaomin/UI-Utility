/* */ 
var $export = require('./$.export');
$export($export.S, 'Number', {MIN_SAFE_INTEGER: -0x1fffffffffffff});
