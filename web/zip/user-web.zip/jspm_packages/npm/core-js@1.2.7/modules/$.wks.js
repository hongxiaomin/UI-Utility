/* */ 
var store = require('./$.shared')('wks'),
    uid = require('./$.uid'),
    Symbol = require('./$.global').Symbol;
module.exports = function(name) {
  return store[name] || (store[name] = Symbol && Symbol[name] || (Symbol || uid)('Symbol.' + name));
};
