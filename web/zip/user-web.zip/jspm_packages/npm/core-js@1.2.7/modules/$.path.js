/* */ 
module.exports = require('./$.global');
