/* */ 
var $export = require('./$.export');
$export($export.S, 'Number', {MAX_SAFE_INTEGER: 0x1fffffffffffff});
