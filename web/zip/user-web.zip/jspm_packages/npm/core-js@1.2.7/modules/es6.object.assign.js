/* */ 
var $export = require('./$.export');
$export($export.S + $export.F, 'Object', {assign: require('./$.object-assign')});
