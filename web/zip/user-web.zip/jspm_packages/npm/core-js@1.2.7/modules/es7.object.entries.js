/* */ 
var $export = require('./$.export'),
    $entries = require('./$.object-to-array')(true);
$export($export.S, 'Object', {entries: function entries(it) {
    return $entries(it);
  }});
