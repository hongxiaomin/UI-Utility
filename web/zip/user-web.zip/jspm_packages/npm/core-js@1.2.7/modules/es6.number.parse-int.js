/* */ 
var $export = require('./$.export');
$export($export.S, 'Number', {parseInt: parseInt});
