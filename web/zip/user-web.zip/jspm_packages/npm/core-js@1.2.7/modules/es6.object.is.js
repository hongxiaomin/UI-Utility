/* */ 
var $export = require('./$.export');
$export($export.S, 'Object', {is: require('./$.same-value')});
