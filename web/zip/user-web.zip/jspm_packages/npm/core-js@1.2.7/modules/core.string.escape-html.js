/* */ 
'use strict';
var $export = require('./$.export');
var $re = require('./$.replacer')(/[&<>"']/g, {
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&apos;'
});
$export($export.P + $export.F, 'String', {escapeHTML: function escapeHTML() {
    return $re(this);
  }});
