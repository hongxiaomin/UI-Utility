/* */ 
var $ = require('./$'),
    has = require('./$.has'),
    $export = require('./$.export'),
    isObject = require('./$.is-object'),
    anObject = require('./$.an-object');
function get(target, propertyKey) {
  var receiver = arguments.length < 3 ? target : arguments[2],
      desc,
      proto;
  if (anObject(target) === receiver)
    return target[propertyKey];
  if (desc = $.getDesc(target, propertyKey))
    return has(desc, 'value') ? desc.value : desc.get !== undefined ? desc.get.call(receiver) : undefined;
  if (isObject(proto = $.getProto(target)))
    return get(proto, propertyKey, receiver);
}
$export($export.S, 'Reflect', {get: get});
