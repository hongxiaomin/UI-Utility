/* */ 
require('./$.object-sap')('getOwnPropertyNames', function() {
  return require('./$.get-names').get;
});
