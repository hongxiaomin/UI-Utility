/* */ 
'use strict';
var toObject = require('./$.to-object'),
    toIndex = require('./$.to-index'),
    toLength = require('./$.to-length');
module.exports = [].copyWithin || function copyWithin(target, start) {
  var O = toObject(this),
      len = toLength(O.length),
      to = toIndex(target, len),
      from = toIndex(start, len),
      $$ = arguments,
      end = $$.length > 2 ? $$[2] : undefined,
      count = Math.min((end === undefined ? len : toIndex(end, len)) - from, len - to),
      inc = 1;
  if (from < to && to < from + count) {
    inc = -1;
    from += count - 1;
    to += count - 1;
  }
  while (count-- > 0) {
    if (from in O)
      O[to] = O[from];
    else
      delete O[to];
    to += inc;
    from += inc;
  }
  return O;
};
