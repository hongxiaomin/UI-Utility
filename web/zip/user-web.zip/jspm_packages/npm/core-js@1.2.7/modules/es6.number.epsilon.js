/* */ 
var $export = require('./$.export');
$export($export.S, 'Number', {EPSILON: Math.pow(2, -52)});
