/* */ 
var $export = require('./$.export');
$export($export.S, 'Math', {log1p: require('./$.math-log1p')});
