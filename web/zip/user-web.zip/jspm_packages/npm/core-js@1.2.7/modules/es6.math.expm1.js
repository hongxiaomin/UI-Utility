/* */ 
var $export = require('./$.export');
$export($export.S, 'Math', {expm1: require('./$.math-expm1')});
