/* */ 
var $export = require('./$.export');
$export($export.S, 'Number', {isInteger: require('./$.is-integer')});
