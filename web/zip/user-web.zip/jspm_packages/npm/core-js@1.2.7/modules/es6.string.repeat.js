/* */ 
var $export = require('./$.export');
$export($export.P, 'String', {repeat: require('./$.string-repeat')});
