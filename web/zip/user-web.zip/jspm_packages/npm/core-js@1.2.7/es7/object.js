/* */ 
require('../modules/es7.object.get-own-property-descriptors');
require('../modules/es7.object.values');
require('../modules/es7.object.entries');
module.exports = require('../modules/$.core').Object;
