/* */ 
require('../modules/es7.map.to-json');
module.exports = require('../modules/$.core').Map;
