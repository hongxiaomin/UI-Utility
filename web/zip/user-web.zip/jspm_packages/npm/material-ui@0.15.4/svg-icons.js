/* */ 
module.exports = require('./svg-icons/index');
