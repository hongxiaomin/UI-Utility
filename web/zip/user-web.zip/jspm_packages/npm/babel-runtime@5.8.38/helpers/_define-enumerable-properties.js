/* */ 
module.exports = require('./defineEnumerableProperties');
