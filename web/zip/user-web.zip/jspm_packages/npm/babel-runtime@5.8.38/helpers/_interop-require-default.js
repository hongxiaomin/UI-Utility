/* */ 
module.exports = require('./interopRequireDefault');
