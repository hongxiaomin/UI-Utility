/* */ 
module.exports = require('./createClass');
