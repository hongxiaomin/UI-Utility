/* */ 
module.exports = { "default": require("core-js/library/fn/is-iterable"), __esModule: true };