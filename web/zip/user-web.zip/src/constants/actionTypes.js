export const ROUTER_LOCATION_CHANGE = '@@router/LOCATION_CHANGE';
export const SET_MQTT_DATA = 'SET_MQTT_DATA';
export const SET_REST_DATA = 'SET_REST_DATA';
